let count = 0;
let images = [
  "images/평소.jpg",
  "images/맞음.jpg"
];
const ouchImage = document.getElementById('여명');
const ouchCount = document.getElementById('hit_num');

ouchImage.addEventListener('click', function() {
  count++;
  if (count >= images.length) {
    count = 0;
  }
  ouchCount.textContent = count;
  ouchImage.src = images[count];
  ouchImage.style.pointerEvents = 'none';

  setTimeout(function() {
    ouchImage.src = images[count === 0 ? 1 : 0]; 
    ouchImage.style.pointerEvents = 'auto'; 
  }, 500);

  alert("여명: 아이고!");
});
